// プロライン配信の送信前チェック。
// 「メッセージを送信」を押す画面（配信画面）で、押す直前に丸ごと実行する。
// 送信時はこの画面に読み込まれている中身で下書きが上書きされてから送られる＝この画面の中身が「実際に届く中身」。
// 画面の作りが変わると動かなくなる。NGが出たら画面を目でも確かめること。
// このチェックが見ないもの（送る前の確認ダイアログで目で見る）：
//   送信タイミングが「即時」か／「配信時刻をランダムで早める」が外れているか／「送信直前に再度対象者をチェック」がONか／
//   画面に出ていない2組目の送信設定／カード画像が空でないか／戻り値のURLと本文のリンクが合っているか
(() => {
  const EXCEPT = /zoom/i;   // LINE内ブラウザをOFFのままでよいURL（アプリで開かせたいもの）。例外なしなら null にする
  const isExcept = s => EXCEPT ? EXCEPT.test(s) : false;
  const ng = [], note = [];
  if (!/select-user/.test(location.pathname)) ng.push('NG: 配信画面ではない（' + location.pathname + '）');

  // 下書き：選ばずに送ると空のメッセージが届く
  const sel = document.querySelector('select[name*=template]');
  const draft = sel && sel.value ? sel.value : '';
  if (!draft) ng.push('NG: 下書きが選ばれていない（このまま送ると空のメッセージが届く）');

  // リンク：全部LINE内ブラウザONが原則（外のブラウザに出ると戻ってこない）
  const cbs = [...document.querySelectorAll('input[name^="tracking_url_open_line_browser_"]')];
  if (!cbs.length) note.push('リンク設定が0件（リンクの無い配信なら問題なし。あるはずなら「▼編集する▼」を開いて再実行）');
  let exceptOff = 0;
  const bad = cbs.filter(c => !c.checked).map(c => {
    const id = c.name.replace('tracking_url_open_line_browser_', '');
    const mid = id.split('_')[0];
    // 本文中のURLは名前にIDが付かないことがあるので、見つからなければ並び順で拾う（ずれることがある→目で照らす）
    let shows = [...document.querySelectorAll(`[name="tracking_url_original_url_show_${mid}[]"]`)].map(i => i.value);
    if (!shows.length) { const all = [...document.querySelectorAll('[name^="tracking_url_original_url_show"]')].map(i => i.value); shows = [all[cbs.indexOf(c)] || '']; }
    return id + '（' + shows.join(' / ') + '）';
  }).filter(s => { if (isExcept(s)) { exceptOff++; return false; } return true; });
  if (bad.length) ng.push('NG: LINE内ブラウザOFF → ' + bad.join(', '));

  // 除外タグ：「全てを満たす」(AND) でないと、思ったより多くの人が外れる／外れない
  const area = document.querySelector('#condition_tags_option_area');
  if (!area) note.push('絞り込み条件の欄が見つからない → 除外タグは目で確かめる');
  else {
    // 画面の作りを確かめられていないので粗い判定：欄の中に「除外」があって「全てを満たす」が1つも無ければNG。
    // 「含む」側が全てを満たす・除外側がいずれか、の組み合わせはすり抜けるので、除外側は必ず目で見る
    if (/除外/.test(area.innerText) && !/全てを満たす/.test(area.innerText)) ng.push('NG: 除外タグが「いずれかを満たす」になっている → 「全てを満たす」に');
    if (/除外/.test(area.innerText)) note.push('除外タグの欄が「全てを満たす」になっているかは目でも確かめる');
  }

  // 人数：読めなければ目で見る
  const cnt = (document.body.innerText.match(/送信可能数:\s*([0-9,]+)/) || [])[1];
  if (!cnt) note.push('送信可能数が読めない → 人数は目で確かめる');

  if (ng.length) return ng.concat(note.map(n => '注意: ' + n)).join('\n');
  return `PREFLIGHT_OK draft=${draft} 送信可能数=${cnt || '?'} リンク${cbs.length}件中、例外${exceptOff}件を除き全部LINE内ブラウザON`
    + (note.length ? '\n注意: ' + note.join('\n注意: ') : '');
})()
