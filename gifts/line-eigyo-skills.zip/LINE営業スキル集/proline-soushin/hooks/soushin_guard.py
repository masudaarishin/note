#!/usr/bin/env python3
"""プロライン配信の「送信」操作を、送信前チェック（preflight.js）が通るまで止める。Claude Code 用。

できること・できないこと（先に読む）
  - AIがブラウザを操作するとき、操作の中身や説明文に「送信」系の語があれば止める。
  - 文字で見ているだけなので、座標だけのクリックや、送信系の語を含まない説明の操作は止まらない。
    「これを入れれば絶対に誤送信しない」ものではない。最後に人が画面を見ることは変わらない。
  - 逆に、送信でない操作も止まることがある（下書き一覧を開く、ファイル名に「送信」が入っている など）。
    送信でない操作の説明やファイル名に、送信系の語を使わないようにすると止まりにくい。
  - OKの記録は配信を区別しない。10分以内なら別の配信の送信も通る。1回送ったら次の配信でチェックし直す。

入れ方
  1. このファイルを ~/.claude/hooks/soushin_guard.py に置く
  2. ~/.claude/settings.json に次を足す（すでに hooks があれば PreToolUse の配列に足す）
     {
       "hooks": {
         "PreToolUse": [
           {"matcher": "mcp__.*",
            "hooks": [{"type": "command", "command": "python3 ~/.claude/hooks/soushin_guard.py"}]}
         ]
       }
     }
     終了コード2で止まり、下の説明文がAIに返る。
  3. 自分の環境のブラウザ操作の道具の名前を確かめ、BROWSER_TOOLS に無ければ足す
     （Claude Code の /mcp で道具の一覧が見られる）

使い方
  送信前チェックが PREFLIGHT_OK を返したら:
    python3 ~/.claude/hooks/soushin_guard.py ok "<preflight.js の戻り値そのまま>"
  これで10分間だけ送信操作が通る。
"""
import json, re, sys, time
from pathlib import Path

MARK = Path.home() / ".claude/hooks/state/soushin_preflight.json"
VALID_SEC = 600
# 日本語：画面のボタンの文字。英語：AIの操作に付く説明文（英語で書かれることが多い）。
# 「メッセージを送信しました」はテスト送信の完了表示なので除く（これを止めると確認ができない）。
SEND_RE = re.compile(
    r"btn-submit-message-template|メッセージを送信(?!しました)|臨時メッセージを送信|配信を送信|送信を確定|"
    r"broadcast|confirms? send|sending the|send(s)? (the )?(message|broadcast) to",
    re.I,
)
BROWSER_TOOLS = ("mcp__claude-in-chrome__", "mcp__Claude_Browser__", "mcp__Control_Chrome__",
                 "mcp__remote-devices__Claude_Browser__")


def hook():
    try:
        data = json.load(sys.stdin)
    except Exception:
        return 0
    if not data.get("tool_name", "").startswith(BROWSER_TOOLS):
        return 0
    if not SEND_RE.search(json.dumps(data.get("tool_input", {}), ensure_ascii=False)):
        return 0
    try:
        m = json.loads(MARK.read_text())
        if time.time() - m["ts"] < VALID_SEC and m["result"].startswith("PREFLIGHT_OK"):
            return 0
    except Exception:
        pass
    sys.stderr.write(
        "【送信ガード】送信ボタンを押す前に、送信前チェックが必要です。\n"
        "0. 送るのは、人が『送って』と言ったときだけ\n"
        "1. 下書きを直したなら、配信画面を開き直し、絞り込み条件を入れ直す\n"
        "2. 配信画面で preflight.js を実行する\n"
        "3. 戻り値が PREFLIGHT_OK なら: python3 ~/.claude/hooks/soushin_guard.py ok \"<戻り値>\"（10分有効）\n"
        "4. 送信後に履歴で見つからなくても再送しない。人に聞く。\n")
    return 2


def ok(result):
    if not result.startswith("PREFLIGHT_OK"):
        print("PREFLIGHT_OK で始まっていないので記録しません")
        return 1
    MARK.parent.mkdir(parents=True, exist_ok=True)
    MARK.write_text(json.dumps({"ts": time.time(), "result": result}, ensure_ascii=False))
    print("記録しました（10分有効）")
    return 0


if __name__ == "__main__":
    sys.exit(ok(sys.argv[2]) if len(sys.argv) > 2 and sys.argv[1] == "ok" else hook())
